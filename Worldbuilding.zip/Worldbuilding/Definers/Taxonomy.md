---
cssclasses:
  - small
aliases:
  - "#taxonomy"
tags:
  - planes/terra
---
[[Hictot]] #taxonomy 
- #taxonomy/nontotae
- #taxonomy/unapars 
- #taxonomy/plurpars
	- #taxonomy/plurpars/densae
	- #taxonomy/plurpars/virids 
		- #taxonomy/plurpars/virids/allovirids 
		- #taxonomy/plurpars/virids/calvovirids 
		- #taxonomy/plurpars/virids/colorovirids 
	- #taxonomy/plurpars/motae 
		- #taxonomy/plurpars/motae/plurdirae 
		- #taxonomy/plurpars/motae/parvae 
			- #taxonomy/plurpars/motae/parvae/aquatestae 
			- #taxonomy/plurpars/motae/parvae/aquaparvae 
			- #taxonomy/plurpars/motae/parvae/minuomonstrae 
		- #taxonomy/plurpars/motae/chordatae 
			- #taxonomy/plurpars/motae/chordatae/pisciae 
			- #taxonomy/plurpars/motae/chordatae/frigae 
				- #taxonomy/plurpars/motae/chordatae/frigae/magnomonstrae 
				- #taxonomy/plurpars/motae/chordatae/frigae/terae
			- #taxonomy/plurpars/motae/chordatae/calorae 
				- #taxonomy/plurpars/motae/chordatae/calorae/extrocalorae
				- #taxonomy/plurpars/motae/chordatae/calorae/introcalorae 
