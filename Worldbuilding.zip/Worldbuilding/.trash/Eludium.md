A group of elusive elements, all turn their specific kind of energy into #energy/ascendent 

^general
Turns #energy/chemical into #energy/ascendent 
^1
Turns #energy/thermal into #energy/ascendent 
^2
Turns #energy/light into #energy/ascendent 
^3
