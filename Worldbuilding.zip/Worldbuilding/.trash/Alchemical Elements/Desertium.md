Turns #energy/thermal into #energy/luck 
