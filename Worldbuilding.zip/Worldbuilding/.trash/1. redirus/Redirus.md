The top plane.
In its centre there's a white hole. It's connected to the black hole in [[Retentus]].
![[Redirus.jpg|200]]