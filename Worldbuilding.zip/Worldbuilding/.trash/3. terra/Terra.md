Main plane of existence.
Has enough chaos and order for creation of life.
![[Terra.jpeg|200]]
