The bottom plane.
In its centre, there's a black hole. It's connected to the white hole in [[Redirus]].
![[Retentus.jpg|200]]