The plane of chaos. Doesn't have enough order to have life.
![[Infera.jpg|200]]