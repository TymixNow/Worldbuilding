The second plane of existence, with too little chaos to create life.
![[Aera.jpg|200]]