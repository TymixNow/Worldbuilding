---
tags:
  - climates/rainforest
  - date/24/16
  - taxonomy/plurpars/densae
aliases:
  - Serpula Sapiens
---
 