---
date: <%tp.date.now("DD.MM.YYYY",-1)%>
week: <%tp.date.now("ww[/]YYYY",-1)%>
---

Daily note of: <%tp.date.now("DD MMM YYYY [(]wo dddd [of the year)]")%>
Note from a month earlier:
![[<%tp.date.now("DD.MM.YYYY",P-1M)%> ]]
<< [[<%tp.date.now("DD.MM.YYYY",-1)%> ]]- [[<%tp.date.now("DD.MM.YYYY",1)%>]] >>
<% tp.web.daily_quote() %>

