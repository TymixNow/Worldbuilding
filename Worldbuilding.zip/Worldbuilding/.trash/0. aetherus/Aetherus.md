The plane which all the others are submerged in.
![[Aetherus.png|200]]