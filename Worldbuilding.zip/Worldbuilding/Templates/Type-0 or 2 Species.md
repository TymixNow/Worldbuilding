---
aliases: 
tags:
  - climates/arid/cold
  - climates/arid/hot
  - climates/continental
  - climates/ice-cap
  - climates/mediterranean
  - climates/oceanic
  - climates/rainforest
  - climates/savanna
  - climates/swamp
  - climates/tundra
  - <%tp.date.now("[date/]gg[/]ww")%>
  - taxonomy
---
Species of (==clade==), adapted to (==condition==).