---
aliases: 
tags:
  - climates/arid/cold
  - climates/arid/hot
  - climates/continental
  - climates/ice-cap
  - climates/mediterranean
  - climates/oceanic
  - climates/rainforest
  - climates/savanna
  - climates/swamp
  - climates/tundra
  - <%tp.date.now("[date/]gg[/]ww")%>
  - energy/ascendent
  - energy/chemical
  - energy/gravitational
  - energy/kinetic
  - energy/light
  - energy/luck
  - energy/thermal
  - elements
  - taxonomy
---
Species of (==clade==), Its (==part==) contains (==element==) that lets it (==action==) allowing the (==kingdom==) to (==benefit==).