```dataview
table taxonomy
from "Species"
sort taxonomy
```
