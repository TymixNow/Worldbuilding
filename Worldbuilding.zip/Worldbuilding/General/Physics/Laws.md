# Energetic Laws:
## Energy Obtainment Law
<div class="jb"> Elements have the ability to internalise energy. </div>

## Energy Storage Law
<div class="jb"> Elements store internalised energy.</div>

## Energy Release Law
<div class="jb">Elements are able to release stored energy.</div>

## Energy Specificity Law
<div class="jb">The form of energy internalised and released by elements is specific to them. </div>
