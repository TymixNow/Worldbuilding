All planes are submerged in the #planes/aetherus plane.
The other planes from the top:
- #planes/redirus
- #planes/aera
- #planes/terra
- #planes/infera
- #planes/retentus 
![[Plane Alignment.png|200]]
# Centres
The centre of #planes/redirus is connected by what is understood as an asymptotic wormhole to the centre of #planes/retentus. 
The centre of #planes/redirus acts as an entrance (black hole) for souls and consciousnesses and an exit (white hole) for matter. Meanwhile, the centre of #planes/retentus acts as an entrance for matter and an exit for souls and consciousnesses.
