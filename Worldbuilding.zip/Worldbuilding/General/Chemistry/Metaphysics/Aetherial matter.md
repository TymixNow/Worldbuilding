---
aliases:
  - Aetherium
---
Matter, creatures from #planes/aetherus are made of. Can mimic any other matter when in any other plane. [[Species/! Puppets|! Puppets]] are made from it.
