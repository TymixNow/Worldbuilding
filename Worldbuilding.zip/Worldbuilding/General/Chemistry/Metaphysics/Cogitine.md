---
tags:
  - date/24/19
  - planes/terra
  - planes/infera
  - planes/aera
  - planes/aetherus
---
A substance [[Manifestation Puppet|Manifestation Puppets]] leave behind as they disappear. Behaves like physical matter, with three exceptions:
1. It's unable to interact with physical matter, only other cogitone matter of the same recipient.
2. It can be interacted with and perceived only by the [[Manifestation Puppet]]'s recipient.
3. It can be controlled by the recipient's thoughts.