---
aliases:
  - "#elements/descendents"
  - Elicerium
  - Infernium
  - Malortium
  - Morium
---
A group of elements, all turn #energy/ascendent into their specific kind of energy.
# Elicerium
Turns #energy/ascendent into #energy/light 
# Infernium
Turns #energy/ascendent into #energy/thermal 
# Malortium
Turns #energy/ascendent into #energy/gravitational 
# Morium
Turns #energy/ascendent into #energy/chemical 