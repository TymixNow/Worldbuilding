---
aliases:
  - "#elements/luxials"
  - Lumenium
  - Luxium
  - Stellium
  - Thermolumenium
---
A group of elements, all turn their specific kind of energy into #energy/light.
# Lumenium
Acts as storage for #energy/light 
# Luxium
Turns #energy/kinetic into #energy/light 
# Stellium
Turns #energy/chemical into #energy/light 
# Thermolumenium
Turns #energy/thermal into #energy/light 