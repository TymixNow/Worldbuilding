---
aliases:
  - "#elements/reactives"
  - Arboraltium
  - Combustium
  - Frigium
---
A group of elements, all turn their specific kind of energy into #energy/chemical .
# Arboraltium
Turns #energy/kinetic into #energy/chemical 
# Combustium
Acts as storage for #energy/chemical 
# Frigium
Turns #energy/thermal into #energy/chemical 