---
aliases:
  - "#elements/ortia"
  - Solortium
  - Thermortium
  - Vivortium
---
A group of elements, all turn their specific kind of energy into #energy/gravitational.
# Solortium 
Turns #energy/light into #energy/gravitational 
# Thermortium
Turns #energy/thermal  into #energy/gravitational 
# Vivortium
Turns #energy/chemical into #energy/gravitational 