---
aliases:
  - "#elements/felicials"
  - Desertium
  - Amuletium
  - Sagittium
  - Solfelicium
---
A group of elements, all turn their specific kind of energy into #energy/luck.
# Desertium
Turns #energy/thermal into #energy/luck 
# Amuletium
Turns #energy/chemical into #energy/luck 
# Sagittium
Turns #energy/kinetic into #energy/luck 
# Solfelicium
Turns #energy/light into #energy/luck 