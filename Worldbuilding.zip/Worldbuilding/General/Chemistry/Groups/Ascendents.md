---
aliases:
  - "#elements/ascendents"
  - Ascendium
  - Eludium
  - Eludium I
  - Eludium II
  - Eludium III
---

A group of elusive elements, all turn their specific kind of energy into #energy/ascendent, most prominent in asteroids.
# Ascendium
Final goal of the game.
Turns #energy/kinetic into #energy/ascendent 
# Eludiae
## Eludium I
Turns #energy/chemical into #energy/ascendent 
## Eludium II
Turns #energy/thermal into #energy/ascendent 
## Eludium III
Turns #energy/light into #energy/ascendent 
