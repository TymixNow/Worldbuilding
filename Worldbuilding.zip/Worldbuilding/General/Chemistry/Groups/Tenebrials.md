---
aliases:
  - "#elements/tenebrials"
  - Herbium
  - Tenebrium
---
A group of elements, all turn #energy/light into their specific kind of energy.
# Herbium
Turns #energy/light into #energy/chemical 
# Tenebrium
Turns #energy/light into #energy/thermal 
