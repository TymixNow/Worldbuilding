

| [[General/Chemistry/Tables/Energy change chart\|Group]] | [[General/Chemistry/Tables/Energy change chart\|Elements]] | Enzymatic?        | Metallicity |
| ------------------------------------------------------- | ---------------------------------------------------------- | ----------------- | ----------- |
| [[General/Chemistry/Groups/Ascendents\|Ascendents]]     | [[General/Chemistry/Groups/Ascendents\|Ascendium]]         | Not naturally     | Yes         |
|                                                         | [[General/Chemistry/Groups/Ascendents\|Eludium I]]         | No                | Yes         |
|                                                         | [[General/Chemistry/Groups/Ascendents\|Eludium II]]        | No                | Yes         |
|                                                         | [[General/Chemistry/Groups/Ascendents\|Eludium III]]       | No                | Yes         |
| [[General/Chemistry/Groups/Ortia\|Ortia]]               | [[General/Chemistry/Groups/Ortia\|Solortium]]              |                   |             |
|                                                         | [[General/Chemistry/Groups/Ortia\|Thermortium]]            |                   |             |
|                                                         | [[General/Chemistry/Groups/Ortia\|Vivortium]]              |                   |             |
| [[General/Chemistry/Groups/Felicials\|Felicials]]       | [[General/Chemistry/Groups/Felicials\|Desertium]]          |                   |             |
|                                                         | [[General/Chemistry/Groups/Felicials\|Amuletium]]          |                   |             |
|                                                         | [[General/Chemistry/Groups/Felicials\|Sagittium]]          |                   |             |
|                                                         | [[General/Chemistry/Groups/Felicials\|Solfelicium]]        |                   |             |
| [[General/Chemistry/Groups/Luxials\|Luxials]]           | [[General/Chemistry/Groups/Luxials\|Lumenium]]             | Yes               |             |
|                                                         | [[General/Chemistry/Groups/Luxials\|Luxium]]               | Yes               |             |
|                                                         | [[General/Chemistry/Groups/Luxials\|Stellium]]             | Yes               |             |
|                                                         | [[General/Chemistry/Groups/Luxials\|Thermolumenium]]       | Yes               |             |
| [[General/Chemistry/Groups/Reactives\|Reactives]]       | [[General/Chemistry/Groups/Reactives\|Arboraltium]]        | Yes               |             |
|                                                         | [[General/Chemistry/Groups/Reactives\|Combustium]]         | Yes               |             |
|                                                         | [[General/Chemistry/Groups/Reactives\|Frigium]]            | Yes               |             |
| [[General/Chemistry/Groups/Tenebrials\|Tenebrials]]     | [[General/Chemistry/Groups/Tenebrials\|Herbium]]           | Yes               |             |
|                                                         | [[General/Chemistry/Groups/Tenebrials\|Tenebrium]]         | Yes               |             |
| [[General/Chemistry/Groups/Descendents\|Descendents]]   | [[General/Chemistry/Groups/Descendents\|Elicerium]]        | In #planes/infera | No          |
|                                                         | [[General/Chemistry/Groups/Descendents\|Infernium]]        | In #planes/infera | No          |
|                                                         | [[General/Chemistry/Groups/Descendents\|Malortium]]        | In #planes/infera | No          |
|                                                         | [[General/Chemistry/Groups/Descendents\|Morium]]           | In #planes/infera | No          |


