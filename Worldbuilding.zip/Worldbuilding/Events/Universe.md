---
start-date: 0-0000-00-00
timelines:
  - aetherus
render?: true
end-date: 2-0000-00-00
---

Created by deities from [[Aetherus]], the Universe is the place, where all the events happen.