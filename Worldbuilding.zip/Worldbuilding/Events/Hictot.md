---
start-date: 0-1500000000-00-00
render?: true
timelines:
  - aetherus
  - terra
end-date: true
body: Planet in terra, that evolved life. Most of the events happen here.
---
Planet in #planes/terra, that evolved life. Most of the events happen here.