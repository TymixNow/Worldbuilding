---
start-date: 0-1000000000-00-00
timelines:
  - aetherus
  - terra
render?: true
end-date: true
---
The star that the planet of [[Hictot]] Orbits 