---
aliases:
  - Kali Sagittus
tags:
  - climates/arid/cold
  - climates/arid/hot
  - climates/savanna
  - climates/mediterranean
  - date/24/18
  - elements/felicials/sagittium
  - energy/kinetic
  - energy/luck
  - taxonomy/plurpars/virids/colorovirids
taxonomy: colorovirids
---
A species of Kali. Contains [[General/Chemistry/Groups/Felicials#Sagittium|Sagittium]]. Creates tumbleweeds, which turn kinetical energy of wind into luck, thanks to [[General/Chemistry/Groups/Felicials#Sagittium|Sagittium]]. Thanks to that their seeds germinate at a higher rate (probability).