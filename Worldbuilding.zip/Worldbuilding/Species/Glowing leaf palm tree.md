---
aliases:
  - Euterpe Lux
tags:
  - climates/mediterranean
  - climates/oceanic
  - climates/rainforest
  - date/24/19
  - energy/light
  - energy/thermal
  - Elements/tenebrials/Tenebrium
  - taxonomy/plurpars/virids/colorovirids
taxonomy: colorovirids
---
Species of palm tree, Its leaves contain [[General/Chemistry/Groups/Luxials|Thermolumenium]] that lets them glow in the dark allowing the plant to perform photosynthesis at night.