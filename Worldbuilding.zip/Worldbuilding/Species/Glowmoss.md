---
aliases:
  - Sphagnum Lumenus
tags:
  - climates/swamp
  - date/24/18
  - elements/luxials/stellium
  - taxonomy/plurpars/virids/allovirids
  - climates/continental
  - climates/oceanic
  - climates/rainforest
taxonomy: allovirids
---
Species of moss. Uses [[General/Chemistry/Groups/Luxials#Stellium|Stellium]] to feed off of decayed matter by using an enzyme containing [[General/Chemistry/Groups/Luxials#Stellium|Stellium]]
