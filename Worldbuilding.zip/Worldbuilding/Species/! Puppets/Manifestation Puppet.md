---
aliases:
  - Intulocatium Manifestatium
---
A form of [[! Puppets|! Puppet]] that can be perceived and interacted with by only one person. Leaves behind [[General/Chemistry/Metaphysics/Cogitine]] as it disappears.