---
aliases:
  - Intulocatium Qualitativum
---
A [[! Puppets|! Puppet]] of a physical object. It can be distinguished from the object by some trait, such as composition.