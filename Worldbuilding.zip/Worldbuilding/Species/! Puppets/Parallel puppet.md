---
aliases:
  - Intulocatium Parallelis
---
A form of [[Species/! Puppets|! Puppet]] that has been put between planes, and has the ability to push matter in and out of them.