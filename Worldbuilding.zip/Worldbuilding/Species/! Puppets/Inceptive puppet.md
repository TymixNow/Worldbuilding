---
aliases:
  - Intulocatium Inceptivum
---

A form of [[../! Puppets|! Puppet]] which appears when one's unconscious, in their subconscious. Gives tips.