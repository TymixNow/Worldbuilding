---
aliases:
  - Intulocatium Physicum
---
Any [[! Puppets|! Puppet]], that can be perceived and interacted with by more than one person.