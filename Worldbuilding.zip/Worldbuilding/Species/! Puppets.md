---
aliases:
  - Intulocatia
  - Intulocatium
  - "! Puppet"
tags:
  - date/24/19
  - planes/aetherus
  - planes/terra
  - climates/arid/cold
  - climates/arid/hot
  - climates/continental
  - climates/ice-cap
  - climates/mediterranean
  - climates/oceanic
  - climates/rainforest
  - climates/savanna
  - climates/swamp
  - climates/tundra
---
Put in #planes/terra by beings from #planes/aetherus. Crossections of beings from #planes/aetherus.
