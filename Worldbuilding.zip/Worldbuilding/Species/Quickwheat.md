---
tags:
  - taxonomy/plurpars/virids/colorovirids
  - energy/chemical
  - climates/mediterranean
  - date/24/13
  - "#elements/reactives/combustium"
aliases:
  - Triticum Velox
taxonomy: colorovirids
---
Species of wheat, its seeds contain charged [[General/Chemistry/Groups/Reactives#Combustium]] which they use to sprout and emerge very quickly (avg. 20 degree-days). 