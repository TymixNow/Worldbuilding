---
aliases:
  - Acer Velox
tags:
  - date/24/16
  - elements/reactives/arboraltium
  - energy/chemical
  - energy/kinetic
  - taxonomy/plurpars/virids/colorovirids
  - climates/oceanic
  - climates/continental
  - climates/swamp
  - climates/rainforest
taxonomy: colorovirids
---
A species of maple able to sprout quickly thanks to [[General/Chemistry/Groups/Reactives#Arboraltium]]. Seeds charge up with #energy/chemical while they fall.