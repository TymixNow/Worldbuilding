---
tags:
  - taxonomy/plurpars/virids/colorovirids
  - energy/thermal
  - energy/luck
  - climates/arid
  - climates/arid/cold
  - climates/arid/hot
  - date/24/13
  - "#elements/felicials/desertium"
aliases:
  - Selenicereus Felicis
taxonomy: colorovirids
---

Species of dragon fruit, black with white seeds on the inside, green on the outside, contains [[General/Chemistry/Groups/Felicials#Desertium]], which allows for its seeds to germinate at a higher rate (with a high probability).