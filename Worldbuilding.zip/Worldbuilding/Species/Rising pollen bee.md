---
tags:
  - climates/continental
  - date/24/13
  - taxonomy/plurpars/motae/parvae/minuomonstrae
aliases:
  - Apis Mellifera Ortipolinis
taxonomy: minuomonstrae
---
Subspecies of honeybee, adapted to making honey out of [[Rising pollen spruce]] pollen.
