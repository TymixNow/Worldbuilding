---
tags:
  - energy/light
  - energy/gravitational
  - climates/continental
  - climates/tundra
  - date/24/13
  - "#elements/ortia/solortium"
  - taxonomy/plurpars/virids/calvovirids
aliases:
  - Picea Nebulopolinus Ortipollinus
taxonomy: calvovirids
---
Subspecies of pine, Its pollen contains [[General/Chemistry/Groups/Ortia#Solortium]] and floats up during the day, settling down on its flowers and the ground during the night. It pollinates all year, but most intensively in spring.
$$
$$