---
cssclasses:
  - less-indent
  - small
---
# 1. Universe
- [x] [[Plane Alignment|Cosmology]]
- [x] [[General/Chemistry/Tables/Energy change chart|Chemistry]]
# 2. Life
### 1. Type-0 (non-alchemical) and Type-1 (element obtaining) species (based on [[General/Chemistry/Tables/Energy change chart|#elements]], [[Definers/Taxonomy|#taxonomy]] & [[Climate|#climate]])
```dataview
task from "General/Chemistry/Tables/Obtaining chart.md"
```


  - [ ] #taxonomy 
    - [ ] #taxonomy/unapars 
    - [ ] #taxonomy/nontotae 
    - [ ] #taxonomy/plurpars 
        - [x] #taxonomy/plurpars/densae 
      - [ ] #taxonomy/plurpars/virids 
        - [ ] #taxonomy/plurpars/virids/allovirids 
        - [x] #taxonomy/plurpars/virids/calvovirids 
        - [x] #taxonomy/plurpars/virids/colorovirids 
      - [ ] #taxonomy/plurpars/motae 
        - [ ] #taxonomy/plurpars/motae/parvae 
          - [ ] #taxonomy/plurpars/motae/parvae/aquaparvae 
          - [ ] #taxonomy/plurpars/motae/parvae/aquatestae 
          - [ ] #taxonomy/plurpars/motae/parvae/minuomonstrae 
        - [ ] #taxonomy/plurpars/motae/plurdirae 
        - [ ] #taxonomy/plurpars/motae/chordatae 
          - [ ] #taxonomy/plurpars/motae/chordatae/pisciae 
          - [ ] #taxonomy/plurpars/motae/chordatae/frigae 
            - [ ] #taxonomy/plurpars/motae/chordatae/frigae/terae 
            - [ ] #taxonomy/plurpars/motae/chordatae/frigae/magnomonstrae 
  - [ ] #climates 
    - [x] #climates/arid/cold 
    - [x] #climates/arid/hot 
    - [ ] #climates/continental (herbs etc.)
    - [ ] #climates/swamp (water lily etc.)
    - [ ] #climates/mediterranean (more food)
    - [ ] #climates/oceanic (more flowers etc.)
    - [ ] #climates/rainforest (small tree)
    - [ ] #climates/savanna (grass)
    - [ ] #climates/tundra (trees, grass)
### 2. Type-2 (element using) species (based on Type-1 species, [[General/Chemistry/Tables/Energy change chart|Elements]], [[Definers/Taxonomy|Taxonomy]] & [[Definers/Climate|Climate]])
### 3. Type-3 (intelligent) species (based on Type-2 species,[[Definers/Taxonomy|Taxonomy]] & [[Definers/Climate|Climate]])
#### 3.5. Type-3.5 (cultural) species
